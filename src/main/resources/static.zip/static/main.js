const app = Vue.
    createApp({
        data() {
            return {
                message: "Hello Vue!",
                clients: [],
                firstName: "",
                lastName: "",
                id:"",
                email: ""
            }
        },

        created() {

         
                axios.get('/clients')
                    .then(response => {
                        this.clients = response.data._embedded.clients;
                    })

                    .catch(function (error) {
                        console.log(error);
                    })
           
        },
        methods: {

            
            addClient() {
                if (this.firstName.length == "" || this.lastName.length == "" || this.email.length == "") { 
                    return;
                } else { 
                axios.post('/clients', {
                    firstName: this.firstName,
                    lastName: this.lastName,
                    email: this.email,                   
                })
                    
                    .catch(function (error) {
                        console.log(error);
                    });          
                    
                    
            
                
            }},
            
        }
    }).mount('#app');

